package com.wotblitz.tracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF0B1018)
private val Panel = Color(0xFF151E2A)
private val Panel2 = Color(0xFF1D2938)
private val Accent = Color(0xFFE04B4B)
private val Muted = Color(0xFF9AA9BB)
private val WinGreen = Color(0xFF49D17D)
private val Cyan = Color(0xFF53D6E8)
private val Purple = Color(0xFFB68AFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BlitzTrackerApp() }
    }
}

data class Session(val date: String, val battles: Int, val wins: Int, val damage: Int) {
    val losses get() = battles - wins
    val winRate get() = if (battles == 0) 0 else wins * 100 / battles
}

@Composable
fun BlitzTrackerApp() {
    var selectedTab by remember { mutableStateOf(0) }
    var nickname by remember { mutableStateOf("") }
    var sessionStarted by remember { mutableStateOf(false) }
    var battles by remember { mutableIntStateOf(0) }
    var wins by remember { mutableIntStateOf(0) }
    var totalDamage by remember { mutableIntStateOf(0) }
    var showAddBattle by remember { mutableStateOf(false) }
    var showNicknameDialog by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf(listOf<Session>()) }

    val rate = if (battles == 0) 0 else wins * 100 / battles
    val rateColor = when {
        rate < 50 -> Color(0xFFFF6262)
        rate < 60 -> WinGreen
        rate < 65 -> Cyan
        else -> Purple
    }
    val avgDamage = if (battles == 0) 0 else totalDamage / battles

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Bg,
            surface = Panel,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 },
                        icon = { Icon(Icons.Default.Dashboard, null) }, label = { Text("Огляд") })
                    NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 },
                        icon = { Icon(Icons.Default.History, null) }, label = { Text("Історія") })
                    NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2 },
                        icon = { Icon(Icons.Default.Person, null) }, label = { Text("Профіль") })
                    NavigationBarItem(selected = selectedTab == 3, onClick = { selectedTab = 3 },
                        icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Налаштування") })
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Header()
                when (selectedTab) {
                    0 -> Overview(
                        nickname = nickname, battles = battles, wins = wins, rate = rate,
                        rateColor = rateColor, avgDamage = avgDamage, sessionStarted = sessionStarted,
                        onStart = { sessionStarted = true },
                        onFinish = {
                            if (battles > 0) {
                                val date = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date())
                                history = listOf(Session(date, battles, wins, avgDamage)) + history
                            }
                            sessionStarted = false
                            battles = 0; wins = 0; totalDamage = 0
                        },
                        onAddBattle = { showAddBattle = true }
                    )
                    1 -> HistoryScreen(history)
                    2 -> ProfileScreen(nickname, onEdit = { showNicknameDialog = true })
                    else -> SettingsScreen()
                }
            }
        }

        if (showAddBattle) {
            var won by remember { mutableStateOf(true) }
            var damageText by remember { mutableStateOf("1500") }
            AlertDialog(
                onDismissRequest = { showAddBattle = false },
                title = { Text("Додати результат бою") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Перемога")
                            Spacer(Modifier.weight(1f))
                            Switch(checked = won, onCheckedChange = { won = it })
                        }
                        OutlinedTextField(value = damageText, onValueChange = { damageText = it.filter(Char::isDigit).take(5) },
                            label = { Text("Завдана шкода") }, singleLine = true)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        battles++
                        if (won) wins++
                        totalDamage += damageText.toIntOrNull() ?: 0
                        showAddBattle = false
                    }) { Text("Зберегти") }
                },
                dismissButton = { TextButton(onClick = { showAddBattle = false }) { Text("Скасувати") } },
                containerColor = Panel
            )
        }

        if (showNicknameDialog) {
            AlertDialog(
                onDismissRequest = { showNicknameDialog = false },
                title = { Text("Нікнейм WoT Blitz") },
                text = {
                    OutlinedTextField(value = nickname, onValueChange = { nickname = it.trim().take(32) },
                        label = { Text("Нікнейм EU") }, singleLine = true)
                },
                confirmButton = { TextButton(onClick = { showNicknameDialog = false }) { Text("Зберегти") } },
                containerColor = Panel
            )
        }
    }
}

@Composable
fun Header() {
    Row(
        Modifier.fillMaxWidth().background(Panel).padding(horizontal = 18.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(42.dp).background(Accent, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Bolt, contentDescription = null, tint = Color.White)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("BLITZ TRACKER", fontSize = 19.sp, fontWeight = FontWeight.Black, letterSpacing = 1.3.sp)
            Text("SESSION CONTROL", fontSize = 10.sp, color = Muted, letterSpacing = 2.sp)
        }
        Box(Modifier.background(Color(0xFF263A32), RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 6.dp)) {
            Text("BETA", color = WinGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun Overview(
    nickname: String, battles: Int, wins: Int, rate: Int, rateColor: Color, avgDamage: Int,
    sessionStarted: Boolean, onStart: () -> Unit, onFinish: () -> Unit, onAddBattle: () -> Unit
) {
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 18.dp, bottom = 22.dp)
    ) {
        item {
            Text("ТВОЯ СЕСІЯ", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(4.dp))
            Text(if (nickname.isBlank()) "Готовий до бою?" else nickname, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text(if (sessionStarted) "● Сесію розпочато" else "Сесія не активна", color = if (sessionStarted) WinGreen else Muted, fontSize = 13.sp)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("БОЇ", battles.toString(), Color(0xFF61A8FF), Modifier.weight(1f))
                StatCard("ПЕРЕМОГИ", wins.toString(), WinGreen, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("ВІДСОТОК ПЕРЕМОГ", "$rate%", rateColor, Modifier.weight(1f))
                StatCard("СЕРЕДНЯ ШКОДА", "%,d".format(avgDamage), Color(0xFFFFB454), Modifier.weight(1f))
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("КЕРУВАННЯ СЕСІЄЮ", color = Muted, fontSize = 11.sp, letterSpacing = 1.4.sp)
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = if (sessionStarted) onAddBattle else onStart,
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(if (sessionStarted) Icons.Default.Add else Icons.Default.PlayArrow, null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (sessionStarted) "ДОДАТИ РЕЗУЛЬТАТ БОЮ" else "ПОЧАТИ СЕСІЮ", fontWeight = FontWeight.Bold)
                    }
                    if (sessionStarted) {
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = onFinish, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(12.dp)) {
                            Icon(Icons.Default.Stop, null); Spacer(Modifier.width(8.dp)); Text("ЗАВЕРШИТИ СЕСІЮ")
                        }
                    }
                    Text("У цій демоверсії результати боїв додаються вручну.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp))
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel2), shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CloudSync, null, tint = Cyan, modifier = Modifier.size(26.dp))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("Синхронізація", fontWeight = FontWeight.Bold)
                        Text("Підключення до Windows-трекера та сервера буде додано наступним етапом.", color = Muted, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Text(title, fontSize = 10.sp, color = Muted, letterSpacing = 0.6.sp, minLines = 2)
            Text(value, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = color)
            Box(Modifier.padding(top = 8.dp).width(32.dp).height(3.dp).background(color, RoundedCornerShape(3.dp)))
        }
    }
}

@Composable
fun HistoryScreen(history: List<Session>) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("ІСТОРІЯ СЕСІЙ", fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Text("Збережені результати завершених сесій", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(16.dp))
        if (history.isEmpty()) {
            EmptyState("Поки немає сесій", "Заверши першу сесію — її результат з'явиться тут.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(history) { s ->
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                        Column(Modifier.fillMaxWidth().padding(14.dp)) {
                            Text(s.date, color = Muted, fontSize = 12.sp)
                            Spacer(Modifier.height(5.dp))
                            Text("${s.battles} боїв  •  ${s.wins} перемог  •  ${s.losses} поразок", fontWeight = FontWeight.Bold)
                            Text("Перемоги: ${s.winRate}%  •  Середня шкода: ${s.damage}", color = Cyan, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileScreen(nickname: String, onEdit: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("ПРОФІЛЬ ГРАВЦЯ", fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                Box(Modifier.size(64.dp).background(Panel2, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Person, null, tint = Cyan, modifier = Modifier.size(36.dp))
                }
                Spacer(Modifier.height(12.dp))
                Text(if (nickname.isBlank()) "Нікнейм не вказано" else nickname, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Регіон: EU", color = Muted)
                Spacer(Modifier.height(16.dp))
                Button(onClick = onEdit, colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
                    Icon(Icons.Default.Edit, null); Spacer(Modifier.width(8.dp)); Text("Вказати нікнейм")
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Text("Підключення до офіційних даних акаунта буде реалізовано окремо після перевірки доступності API.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun SettingsScreen() {
    var notifications by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("НАЛАШТУВАННЯ", fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("КОЛЬОРИ ВІДСОТКА ПЕРЕМОГ", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                ColorLegend("Менше 50%", Color(0xFFFF6262))
                ColorLegend("50–59,99%", WinGreen)
                ColorLegend("60–64,99%", Cyan)
                ColorLegend("65% і більше", Purple)
                Spacer(Modifier.height(8.dp))
                Text("Колір відсотка перемог змінюється автоматично.", color = Muted, fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Сповіщення", fontWeight = FontWeight.SemiBold)
                    Text("Нагадування та оновлення", color = Muted, fontSize = 12.sp)
                }
                Switch(checked = notifications, onCheckedChange = { notifications = it })
            }
        }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = { showInfo = true }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Info, null); Spacer(Modifier.width(8.dp)); Text("Про застосунок")
        }
        if (showInfo) AlertDialog(
            onDismissRequest = { showInfo = false },
            title = { Text("Blitz Tracker Beta") },
            text = { Text("Перший прототип Android-застосунку. Підключення сервера, хмарної синхронізації та автоматичного імпорту статистики ще не реалізовані.") },
            confirmButton = { TextButton(onClick = { showInfo = false }) { Text("Зрозуміло") } },
            containerColor = Panel
        )
    }
}

@Composable
fun ColorLegend(label: String, color: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).background(color, RoundedCornerShape(50)))
        Spacer(Modifier.width(10.dp))
        Text(label, color = Color.White, fontSize = 13.sp)
    }
}

@Composable
fun EmptyState(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(top = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.BarChart, null, tint = Muted, modifier = Modifier.size(44.dp))
        Spacer(Modifier.height(12.dp))
        Text(title, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}
